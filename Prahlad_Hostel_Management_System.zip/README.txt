PRAHLAD HOSTEL MANAGEMENT SYSTEM
================================

Files
-----
index.html          Web application (Bento Grid, blue theme)
supabase-setup.sql  Database schema, roles, and row-level security
README.txt          Setup guide

TECHNOLOGY
----------
Frontend: HTML/CSS/JavaScript
Database/Auth: Supabase (PostgreSQL + Supabase Auth)
Hosting: Any static web host (Netlify, GitHub Pages, Cloudflare Pages, etc.)

SETUP
-----
1. Create a Supabase project at https://supabase.com/dashboard
2. Open SQL Editor -> New query.
3. Paste the complete contents of supabase-setup.sql and Run.
4. Open Project Settings -> API. Copy:
   - Project URL
   - anon / publishable key (NOT service_role key)
5. Open index.html in a code editor. Find:
   const SUPABASE_URL='YOUR_SUPABASE_PROJECT_URL';
   const SUPABASE_ANON_KEY='YOUR_SUPABASE_ANON_KEY';
   Replace the placeholders with your own project URL and anon key.
6. Create your first user in Supabase -> Authentication -> Users -> Add user.
   Use a secure email and password.
7. Copy that user's UUID. In Supabase SQL Editor run:
   update public.profiles
   set role='super_admin', full_name='Your Name'
   where id='PASTE_AUTH_USER_UUID_HERE';
8. Create the Warden and Principal users in Authentication -> Users.
   Their profiles are created automatically with default role 'principal' (read-only) until you explicitly assign the correct role.
   Update each role in SQL Editor, using the corresponding Auth UUID:
   update public.profiles set role='principal', full_name='Principal Name'
   where id='PRINCIPAL_AUTH_UUID';
   update public.profiles set role='warden', full_name='Warden Name'
   where id='WARDEN_AUTH_UUID';
8. Host the folder on HTTPS static hosting. Open the site and sign in.

ROLE PERMISSIONS
----------------
Super Admin: read/write all operational records; manage user profiles and roles.
Warden: read/write operational records; cannot manage user roles.
Principal: read-only access to records and dashboard.

IMPORTANT SECURITY NOTES
------------------------
- Never put a Supabase service_role key in index.html or any browser code.
- Only use the anon/publishable key in the frontend; database access is protected by RLS.
- Keep account passwords private. Use individual logins, not shared accounts.
- This starter app stores photo_url as a URL field. For actual photo upload, configure a private/public Supabase Storage bucket and signed upload workflow.
- Student ID (UUID) fields in visitor/leave/medical/washing/in-out forms expect the student's database UUID. Use the Students table UUID, not admission number.
- Use HTTPS hosting.
- Back up the database regularly from Supabase.
- This is an initial functional version. Test permissions with separate Super Admin, Principal, and Warden accounts before using real student data.

MODULES INCLUDED
----------------
Dashboard, Student Management, Daily Attendance, Room Management,
Visitors Register, Leave Management, Medical Register, Washing Register,
In-Out Register, Inventory, Notice Board, Reports/CSV Export, User Management.
