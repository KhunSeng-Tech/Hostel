-- Prahlad Hostel Management System
-- Run this entire file in Supabase SQL Editor as project owner.
create extension if not exists pgcrypto;

do $$ begin
 create type public.app_role as enum ('super_admin','principal','principal');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '',
 role public.app_role not null default 'warden',
 created_at timestamptz not null default now()
);

create or replace function public.current_role()
returns public.app_role language sql stable security definer set search_path=public
as $$ select role from public.profiles where id=auth.uid() $$;

create or replace function public.can_manage()
returns boolean language sql stable security definer set search_path=public
as $$ select coalesce(public.current_role() in ('super_admin','warden'),false) $$;

create or replace function public.is_super_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select coalesce(public.current_role()='super_admin',false) $$;

create table if not exists public.rooms (
 id uuid primary key default gen_random_uuid(), room_name text not null unique,
 capacity integer not null default 0, floor text, notes text, created_at timestamptz default now()
);
create table if not exists public.students (
 id uuid primary key default gen_random_uuid(), admission_no text not null unique,
 full_name text not null, class_name text not null, dob date, gender text,
 father_name text, father_phone text, mother_name text, mother_phone text,
 guardian_name text, guardian_phone text, address text, room_id text,
 admission_date date, photo_url text, status text not null default 'Active',
 created_at timestamptz default now()
);
create table if not exists public.attendance (
 id uuid primary key default gen_random_uuid(),
 student_id uuid not null references public.students(id) on delete cascade,
 attendance_date date not null, status text not null check(status in ('Present','Absent','Leave')),
 marked_by uuid references auth.users(id), created_at timestamptz default now(),
 unique(student_id,attendance_date)
);
create table if not exists public.visitors (
 id uuid primary key default gen_random_uuid(), student_id uuid references public.students(id) on delete set null,
 visitor_name text not null, relation text, phone text, visit_date date not null,
 in_time time, out_time time, purpose text, created_at timestamptz default now()
);
create table if not exists public.leave_records (
 id uuid primary key default gen_random_uuid(), student_id uuid references public.students(id) on delete cascade,
 from_date date not null, to_date date not null, reason text not null,
 status text not null default 'Pending', approved_by text, created_at timestamptz default now()
);
create table if not exists public.medical_records (
 id uuid primary key default gen_random_uuid(), student_id uuid references public.students(id) on delete cascade,
 record_date date not null, complaint text not null, treatment text,
 guardian_informed text, remarks text, created_at timestamptz default now()
);
create table if not exists public.washing_records (
 id uuid primary key default gen_random_uuid(), student_id uuid references public.students(id) on delete cascade,
 record_date date not null, items_count integer default 0, status text, remarks text, created_at timestamptz default now()
);
create table if not exists public.inout_records (
 id uuid primary key default gen_random_uuid(), student_id uuid references public.students(id) on delete cascade,
 movement text not null check(movement in ('In','Out')), movement_time timestamptz not null,
 destination text, purpose text, authorized_by text, created_at timestamptz default now()
);
create table if not exists public.inventory (
 id uuid primary key default gen_random_uuid(), item_name text not null, category text,
 quantity numeric not null default 0, unit text, location text, updated_on date, remarks text,
 created_at timestamptz default now()
);
create table if not exists public.notices (
 id uuid primary key default gen_random_uuid(), title text not null, body text not null,
 audience text default 'All', publish_date date, expires_on date, created_at timestamptz default now()
);

-- Enable row-level security on all application tables.
do $$ declare t text; begin
 foreach t in array array['profiles','rooms','students','attendance','visitors','leave_records','medical_records','washing_records','inout_records','inventory','notices'] loop
  execute format('alter table public.%I enable row level security',t);
 end loop;
end $$;

-- Profiles: authenticated users can read profiles; only Super Admin can change roles/profiles.
drop policy if exists "profiles read authenticated" on public.profiles;
create policy "profiles read authenticated" on public.profiles for select to authenticated using (true);
drop policy if exists "profiles super admin manage" on public.profiles;
create policy "profiles super admin manage" on public.profiles for all to authenticated using (public.is_super_admin()) with check (public.is_super_admin());

-- Shared policy: all signed-in roles can read; Super Admin and Warden can write.
do $$ declare t text; begin
 foreach t in array array['rooms','students','attendance','visitors','leave_records','medical_records','washing_records','inout_records','inventory','notices'] loop
  execute format('drop policy if exists %I on public.%I',t||'_read',t);
  execute format('create policy %I on public.%I for select to authenticated using (true)',t||'_read',t);
  execute format('drop policy if exists %I on public.%I',t||'_write',t);
  execute format('create policy %I on public.%I for all to authenticated using (public.can_manage()) with check (public.can_manage())',t||'_write',t);
 end loop;
end $$;

-- Create a profile automatically for new Auth users. Default role is warden;
-- Super Admin should change roles explicitly in profiles after account creation.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
 insert into public.profiles(id,full_name,role)
 values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''), 'warden')
 on conflict(id) do nothing;
 return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- IMPORTANT: after creating your first account, promote it manually:
-- update public.profiles set role='super_admin', full_name='Hostel Super Admin'
-- where id='PASTE_AUTH_USER_UUID_HERE';
